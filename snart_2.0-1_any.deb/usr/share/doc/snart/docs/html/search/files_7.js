var searchData=
[
  ['main_2ec_308',['main.c',['../snart-1_80_2src_2main_8c.html',1,'(Global Namespace)'],['../src_2main_8c.html',1,'(Global Namespace)']]]
];
