var searchData=
[
  ['payload_5fhdr_363',['payload_hdr',['../structnotify.html#a659627a9acc7d1246304dcf99332b4c2',1,'notify']]],
  ['proposal_5fnum_364',['proposal_num',['../structproposal__hdr.html#a02a5944f4219cf8b27f49ccb532d464f',1,'proposal_hdr']]],
  ['proto_5fid_365',['proto_id',['../structproposal__hdr.html#a09911cb9044df6e3bbf6794015f362be',1,'proposal_hdr::proto_id()'],['../structdelete.html#afb3cdcd2e9a96aedc00f0e5ba5a07076',1,'delete::proto_id()']]],
  ['protocol_5fid_366',['protocol_id',['../structnotify__hdr.html#a31781b3e469266ae7e8149dc4c25a2c2',1,'notify_hdr']]]
];
