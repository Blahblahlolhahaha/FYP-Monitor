var searchData=
[
  ['next_5fpayload_392',['NEXT_PAYLOAD',['../ike_8h.html#ad476d83b702eb137799d14ae05514f87',1,'ike.h']]],
  ['notify_5fmsg_5ftype_393',['NOTIFY_MSG_TYPE',['../ike_8h.html#ae624755ca0321660c1c14a51c5afca9a',1,'ike.h']]]
];
