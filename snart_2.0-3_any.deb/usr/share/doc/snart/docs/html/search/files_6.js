var searchData=
[
  ['log_2ec_306',['log.c',['../snart-1_80_2src_2log_8c.html',1,'(Global Namespace)'],['../src_2log_8c.html',1,'(Global Namespace)']]],
  ['log_2eh_307',['log.h',['../include_2log_8h.html',1,'(Global Namespace)'],['../snart-1_80_2include_2log_8h.html',1,'(Global Namespace)']]]
];
