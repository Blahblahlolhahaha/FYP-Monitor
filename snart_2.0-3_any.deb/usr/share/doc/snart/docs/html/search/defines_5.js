var searchData=
[
  ['rx_5fring_5fsize_532',['RX_RING_SIZE',['../main_8c.html#afcfb8ac36c733187de151348eb50ef01',1,'main.c']]]
];
