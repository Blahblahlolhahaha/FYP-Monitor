var searchData=
[
  ['sa_5fpayload_279',['SA_payload',['../structSA__payload.html',1,'']]],
  ['security_280',['Security',['../structSecurity.html',1,'']]]
];
