var searchData=
[
  ['just_20standardised_20stuff_153',['Just standardised stuff',['../md_CONTRIBUTING.html',1,'']]]
];
