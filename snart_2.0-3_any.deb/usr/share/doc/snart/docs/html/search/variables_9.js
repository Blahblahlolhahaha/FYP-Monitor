var searchData=
[
  ['non_5fipsec_358',['non_ipsec',['../main_8c.html#a699203bc36a6bd1bbbc5182eec978762',1,'main.c']]],
  ['num_5fspis_359',['num_spis',['../structdelete.html#a213681ab32b5ccb5013b9cf768392eeb',1,'delete']]],
  ['num_5ftransforms_360',['num_transforms',['../structproposal__hdr.html#a2adc8f36ce0c86fb696513d3ba32f6a7',1,'proposal_hdr']]],
  ['nxt_5fpayload_361',['nxt_payload',['../structrte__isakmp__hdr.html#a6adbfa7329a4eb078119b5cdb4ec1d53',1,'rte_isakmp_hdr::nxt_payload()'],['../structisakmp__payload__hdr.html#a6f5cfaa5e2c4162cfb75630b09563be7',1,'isakmp_payload_hdr::nxt_payload()'],['../structproposal__hdr.html#a95f37a9a31875783f8cd6f8c74938bbe',1,'proposal_hdr::nxt_payload()'],['../structtransform__hdr.html#aee863098dad77ed5556f55e4d4d02e3e',1,'transform_hdr::nxt_payload()']]]
];
