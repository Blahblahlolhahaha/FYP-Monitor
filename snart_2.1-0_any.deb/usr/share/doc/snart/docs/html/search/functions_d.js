var searchData=
[
  ['write_5flog_352',['write_log',['../include_2log_8h.html#a673d1be8b62993af0498966c9c95a089',1,'write_log(char *file_name, char *log, int priority):&#160;log.h'],['../snart-1_80_2include_2log_8h.html#a928954856513bb072171d893d347f39b',1,'write_log(char *file_name, char log[], char **loghash):&#160;log.c'],['../snart-1_80_2src_2log_8c.html#a928954856513bb072171d893d347f39b',1,'write_log(char *file_name, char log[], char **loghash):&#160;log.c'],['../src_2log_8c.html#abd14f59eb13717f28241e7b4295dff25',1,'write_log(char *file_name, char log[], int priority):&#160;log.c']]]
];
