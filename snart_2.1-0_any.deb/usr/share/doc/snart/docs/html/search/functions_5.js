var searchData=
[
  ['initarray_314',['initArray',['../array_8h.html#ae4d4a74e4195ac6c32ca3825ac6ff903',1,'array.h']]]
];
