var searchData=
[
  ['payload_275',['Payload',['../structPayload.html',1,'']]],
  ['proposal_5fhdr_276',['proposal_hdr',['../structproposal__hdr.html',1,'']]],
  ['proposal_5fstruc_277',['proposal_struc',['../structproposal__struc.html',1,'']]]
];
