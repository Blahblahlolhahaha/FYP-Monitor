var searchData=
[
  ['reserved_367',['reserved',['../structproposal__hdr.html#a6e0101f280c889bd1ef01a1dc69efb0a',1,'proposal_hdr::reserved()'],['../structtransform__hdr.html#a77847d2653668afaf34243786def1fc8',1,'transform_hdr::reserved()'],['../structkey__exchange.html#a1c9ef57c7eb616edc5bdfeb8e365e607',1,'key_exchange::reserved()']]],
  ['reserved2_368',['reserved2',['../structtransform__hdr.html#afd8f4e8042347f8b8736c7b23cb8db8a',1,'transform_hdr']]],
  ['responder_5fspi_369',['responder_spi',['../structrte__isakmp__hdr.html#a99a04641063f9f16d08b24eb2ec16ac2',1,'rte_isakmp_hdr::responder_spi()'],['../structtunnel.html#a978f4884e25e04029b9ff6e4986fa0a1',1,'tunnel::responder_spi()']]]
];
