var searchData=
[
  ['client_5fip_329',['client_ip',['../structtunnel.html#ae6d93126a46400c59cf5cf6080c9bc93',1,'tunnel']]],
  ['client_5floaded_330',['client_loaded',['../structtunnel.html#a6985fe6e89db53e91fba34bae5170b63',1,'tunnel']]],
  ['client_5fseq_331',['client_seq',['../structtunnel.html#ae86bc6022abf13b13d73b4d8b65be972',1,'tunnel']]],
  ['client_5fspi_332',['client_spi',['../structtunnel.html#a31faa15f1d6e542c1611e15a4fd80dfc',1,'tunnel']]],
  ['crit_333',['crit',['../structisakmp__payload__hdr.html#ada28877d9c3e42364e645e18129e48ce',1,'isakmp_payload_hdr']]],
  ['current_5ftime_334',['current_time',['../ike_8h.html#a4ac0988f744d25544192dbb85c79f24b',1,'ike.h']]]
];
