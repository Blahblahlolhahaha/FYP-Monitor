var searchData=
[
  ['tx_5fring_5fsize_533',['TX_RING_SIZE',['../main_8c.html#a530086d082c22e371518c2497c6d9014',1,'main.c']]]
];
