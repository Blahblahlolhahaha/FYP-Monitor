var searchData=
[
  ['long_490',['LONG',['../array_8h.html#a1d1cfd8ffb84e947f82999c682b666a7aaee055c4a5aba7d55774e4f1c01dacea',1,'array.h']]]
];
