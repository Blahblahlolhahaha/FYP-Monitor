var searchData=
[
  ['delete_5ftunnel_301',['delete_tunnel',['../ike_8h.html#a4f2f0ec7403dcc0f2227f94c985daf56',1,'ike.h']]]
];
