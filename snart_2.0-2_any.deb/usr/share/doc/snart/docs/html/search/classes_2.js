var searchData=
[
  ['delete_266',['delete',['../structdelete.html',1,'']]]
];
