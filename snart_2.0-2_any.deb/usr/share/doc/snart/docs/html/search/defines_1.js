var searchData=
[
  ['burst_5fsize_527',['BURST_SIZE',['../main_8c.html#a703e079cb598d615c750d24ec7432617',1,'main.c']]]
];
